package myapps.com.example.user.drfarmer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class crops_wheat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crops_wheat);
    }
}
