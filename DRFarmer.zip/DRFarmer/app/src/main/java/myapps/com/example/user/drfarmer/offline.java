package myapps.com.example.user.drfarmer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.GridLayout;
import android.widget.Toast;

public class offline extends AppCompatActivity {
    GridLayout selectCatagory;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline);

        selectCatagory = findViewById(R.id.selectCatagory);

        //set event

        setSingleEvent(selectCatagory);
    }



    private void setSingleEvent(GridLayout selectFirst) {
        //Loop all child item of select first
        for (int i=0; i<selectFirst.getChildCount(); i++)
        {
            CardView cardView = (CardView)selectFirst.getChildAt(i);
            final int finalI = i;
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (finalI ==0){
                        Intent intent = new Intent(offline.this,crops.class);
                        startActivity(intent);
                    }

                    else if (finalI ==1){
                        Intent intent = new Intent(offline.this,vegtable.class);
                        startActivity(intent);
                    }
                    else if (finalI ==2){
                        Intent intent = new Intent(offline.this,fruits.class);
                        startActivity(intent);
                    }
                    else if (finalI ==3){
                        Intent intent = new Intent(offline.this,flower.class);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(offline.this, "null", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}